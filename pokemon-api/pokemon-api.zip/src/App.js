import Pokemon from './components/display';
import './App.css';

function App() {
  return (
    <div className="App">
      <Pokemon />
    </div>
  );
}

export default App;
